def bb():
	print("b")
