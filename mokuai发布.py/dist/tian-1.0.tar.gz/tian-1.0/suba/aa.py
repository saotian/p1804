def aa():
	print("a")
