def cc():
	print("c")
