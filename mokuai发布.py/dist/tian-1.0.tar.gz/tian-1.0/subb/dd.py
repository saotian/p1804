def dd():
	print("d")
