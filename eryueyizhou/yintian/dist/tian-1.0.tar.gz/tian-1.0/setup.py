from distutils.core import setup
setup(name = "tian",version = "1.0",description = "tianzuo",author = "tian",py_modules=["yin.jisuanji"])

