from distutils.core import setup
setup(name = "tian",version = "1.0",description = "tianzuo",author = "tian",py_modules=["suba.aa","suba.bb","subb.cc","subb.dd"])
